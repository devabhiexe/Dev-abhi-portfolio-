# FlashDev Discord Portfolio

## Customize
Open `index.html` and replace:
- `FlashDev` with your preferred brand/name
- Discord contact link (`https://discord.com/`)
- `YOUR_EMAIL@example.com`
- Demo project descriptions/screenshots/links
- Pricing if needed

## Run locally
You can open `index.html` directly in a browser.

For a local server with Node.js:
```bash
npx serve .
```

## Important
Do not put Discord bot tokens, wallet seed phrases, private keys, passwords, or other secrets in this website.
